// ===========================
// KANBAN CRM - FUNCIONALIDAD PRINCIPAL
// ===========================

class KanbanCRM {
    constructor() {
        console.log('🗂️ Inicializando Kanban CRM...');
        
        // Datos del CRM
        this.contacts = [];
        this.tags = [];
        this.columns = [];
        
        // Estado del Kanban
        this.currentEditingColumn = null;
        this.currentContactModal = null;
        this.draggedContact = null;
        
        // Configuración por defecto
        this.defaultColumns = [
            {
                id: 'leads',
                name: '🎯 Prospectos',
                color: '#FF6B6B',
                tagId: null,
                limit: 0
            },
            {
                id: 'contacted',
                name: '📞 Contactados',
                color: '#4ECDC4',
                tagId: null,
                limit: 0
            },
            {
                id: 'negotiating',
                name: '💬 Negociando',
                color: '#45B7D1',
                tagId: null,
                limit: 0
            },
            {
                id: 'clients',
                name: '✅ Clientes',
                color: '#96CEB4',
                tagId: null,
                limit: 0
            }
        ];
        
        this.init();
    }

    async init() {
        try {
            // Cargar datos del CRM principal
            await this.loadCRMData();
            
            // Configurar columnas iniciales
            this.setupDefaultColumns();
            
            // Renderizar interfaz
            this.renderKanban();
            
            // Vincular eventos
            this.bindEvents();
            
            // Actualizar estadísticas
            this.updateStats();
            
            console.log('✅ Kanban CRM inicializado correctamente');
        } catch (error) {
            console.error('❌ Error inicializando Kanban CRM:', error);
        }
    }

    async loadCRMData() {
        try {
            // Intentar obtener datos del CRM principal si está disponible
            if (window.whatsappCRM) {
                this.contacts = window.whatsappCRM.contacts || [];
                this.tags = window.whatsappCRM.tags || [];
                console.log('📊 Datos cargados del CRM principal:', {
                    contacts: this.contacts.length,
                    tags: this.tags.length
                });
            } else {
                // Cargar datos del localStorage como fallback
                this.contacts = JSON.parse(localStorage.getItem('wa_crm_contacts') || '[]');
                this.tags = JSON.parse(localStorage.getItem('wa_crm_tags') || '[]');
                console.log('📁 Datos cargados del localStorage:', {
                    contacts: this.contacts.length,
                    tags: this.tags.length
                });
            }
            
            // Cargar configuración de columnas
            this.columns = JSON.parse(localStorage.getItem('wa_kanban_columns') || '[]');
            
        } catch (error) {
            console.error('Error cargando datos del CRM:', error);
            this.contacts = [];
            this.tags = [];
            this.columns = [];
        }
    }

    setupDefaultColumns() {
        if (this.columns.length === 0) {
            this.columns = [...this.defaultColumns];
            this.saveColumns();
        }
    }

    renderKanban() {
        this.renderBoard();
        this.renderSidebar();
        this.populateTagSelects();
    }

    renderBoard() {
        const board = document.getElementById('kanbanBoard');
        if (!board) return;

        board.innerHTML = this.columns.map(column => this.createColumnHTML(column)).join('');
        
        // Poblar columnas con contactos
        this.columns.forEach(column => {
            this.populateColumn(column.id);
        });
    }

    createColumnHTML(column) {
        const contactCount = this.getColumnContactCount(column.id);
        
        return `
            <div class="kanban-column" data-column-id="${column.id}">
                <div class="column-header">
                    <div class="column-title">
                        <h3 style="color: ${column.color};">${column.name}</h3>
                        <span class="column-count">${contactCount}</span>
                    </div>
                    <div class="column-actions">
                        <button class="column-btn" onclick="kanban.editColumn('${column.id}')" title="Editar columna">
                            ✏️
                        </button>
                        <button class="column-btn" onclick="kanban.deleteColumn('${column.id}')" title="Eliminar columna">
                            🗑️
                        </button>
                    </div>
                </div>
                <div class="column-content" id="column-${column.id}" data-column="${column.id}">
                    ${contactCount === 0 ? this.createDropZoneHTML() : ''}
                </div>
            </div>
        `;
    }

    createDropZoneHTML() {
        return `
            <div class="drop-zone">
                <span>Arrastra contactos aquí</span>
            </div>
        `;
    }

    populateColumn(columnId) {
        const column = this.columns.find(col => col.id === columnId);
        const columnElement = document.getElementById(`column-${columnId}`);
        
        if (!column || !columnElement) return;

        const contacts = this.getContactsForColumn(column);
        
        if (contacts.length === 0) {
            columnElement.innerHTML = this.createDropZoneHTML();
            return;
        }

        columnElement.innerHTML = contacts.map(contact => this.createContactCardHTML(contact)).join('');
    }

    getContactsForColumn(column) {
        if (column.tagId) {
            // Filtrar por etiqueta específica
            return this.contacts.filter(contact => 
                contact.tags && contact.tags.includes(column.tagId)
            );
        } else {
            // Para columnas sin etiqueta específica, mostrar algunos contactos de ejemplo
            const usedContacts = new Set();
            this.columns.forEach(col => {
                if (col.tagId && col.id !== column.id) {
                    this.contacts.forEach(contact => {
                        if (contact.tags && contact.tags.includes(col.tagId)) {
                            usedContacts.add(contact.id || contact.phone);
                        }
                    });
                }
            });
            
            return this.contacts.filter(contact => 
                !usedContacts.has(contact.id || contact.phone)
            ).slice(0, 5); // Mostrar máximo 5 contactos sin etiquetar
        }
    }

    createContactCardHTML(contact) {
        const avatar = this.getContactAvatar(contact);
        const tags = this.getContactTagsHTML(contact);
        const status = this.getContactStatus(contact);
        const lastSeen = this.formatLastSeen(contact.lastSeen);

        return `
            <div class="contact-card" 
                 draggable="true" 
                 data-contact-id="${contact.id || contact.phone}"
                 onclick="kanban.showContactModal('${contact.id || contact.phone}')">
                <div class="contact-header">
                    <div class="contact-avatar">${avatar}</div>
                    <div class="contact-name">${contact.name || contact.phone}</div>
                </div>
                <div class="contact-phone">${contact.phone || 'Sin teléfono'}</div>
                ${tags}
                <div class="contact-meta">
                    <div class="contact-status">
                        <div class="status-indicator ${status}"></div>
                        <span>${lastSeen}</span>
                    </div>
                    <span>${contact.messageCount || 0} msgs</span>
                </div>
            </div>
        `;
    }

    getContactAvatar(contact) {
        if (contact.avatar) return contact.avatar;
        
        const name = contact.name || contact.phone || '';
        if (name.length > 0) {
            return name.charAt(0).toUpperCase();
        }
        return '👤';
    }

    getContactTagsHTML(contact) {
        if (!contact.tags || contact.tags.length === 0) {
            return '';
        }

        const tagElements = contact.tags.slice(0, 3).map(tagId => {
            const tag = this.tags.find(t => t.id === tagId);
            if (!tag) return '';
            
            return `<span class="contact-tag" style="background: ${tag.color};">${tag.name}</span>`;
        }).filter(tag => tag).join('');

        const extraCount = contact.tags.length > 3 ? contact.tags.length - 3 : 0;
        const extra = extraCount > 0 ? `<span class="contact-tag">+${extraCount}</span>` : '';

        return `<div class="contact-tags">${tagElements}${extra}</div>`;
    }

    getContactStatus(contact) {
        if (!contact.lastSeen) return 'offline';
        
        const now = new Date();
        const lastSeen = new Date(contact.lastSeen);
        const diffMinutes = (now - lastSeen) / (1000 * 60);
        
        if (diffMinutes < 5) return 'online';
        if (diffMinutes < 60) return 'away';
        return 'offline';
    }

    formatLastSeen(lastSeen) {
        if (!lastSeen) return 'Desconocido';
        
        const now = new Date();
        const date = new Date(lastSeen);
        const diffMinutes = (now - date) / (1000 * 60);
        
        if (diffMinutes < 1) return 'Ahora';
        if (diffMinutes < 60) return `Hace ${Math.floor(diffMinutes)}m`;
        if (diffMinutes < 1440) return `Hace ${Math.floor(diffMinutes / 60)}h`;
        return `Hace ${Math.floor(diffMinutes / 1440)}d`;
    }

    getColumnContactCount(columnId) {
        const column = this.columns.find(col => col.id === columnId);
        if (!column) return 0;
        
        return this.getContactsForColumn(column).length;
    }

    renderSidebar() {
        // Actualizar estadísticas
        document.getElementById('totalContacts').textContent = this.contacts.length;
        document.getElementById('activeLabels').textContent = this.tags.length;
        
        const untaggedCount = this.contacts.filter(contact => 
            !contact.tags || contact.tags.length === 0
        ).length;
        document.getElementById('untaggedContacts').textContent = untaggedCount;
    }

    populateTagSelects() {
        const select = document.getElementById('columnTag');
        if (!select) return;

        select.innerHTML = '<option value="">Sin etiqueta específica</option>';
        
        this.tags.forEach(tag => {
            const option = document.createElement('option');
            option.value = tag.id;
            option.textContent = tag.name;
            select.appendChild(option);
        });
    }

    bindEvents() {
        // Eventos de los botones principales
        this.bindHeaderEvents();
        
        // Eventos de modales
        this.bindModalEvents();
        
        // Eventos de drag & drop
        this.bindDragDropEvents();
        
        // Eventos de acciones rápidas
        this.bindQuickActions();
    }

    bindHeaderEvents() {
        const refreshBtn = document.getElementById('refreshKanban');
        const addColumnBtn = document.getElementById('addColumn');
        const settingsBtn = document.getElementById('kanbanSettings');

        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshKanban());
        }

        if (addColumnBtn) {
            addColumnBtn.addEventListener('click', () => this.showColumnModal());
        }

        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => this.showSettings());
        }
    }

    bindModalEvents() {
        // Modal de columnas
        const closeColumnModal = document.getElementById('closeColumnModal');
        const cancelColumn = document.getElementById('cancelColumn');
        const saveColumn = document.getElementById('saveColumn');

        if (closeColumnModal) closeColumnModal.addEventListener('click', () => this.closeColumnModal());
        if (cancelColumn) cancelColumn.addEventListener('click', () => this.closeColumnModal());
        if (saveColumn) saveColumn.addEventListener('click', () => this.saveColumnModal());

        // Modal de contactos
        const closeContactModal = document.getElementById('closeContactModal');
        const openChat = document.getElementById('openChat');
        const editContact = document.getElementById('editContact');
        const manageContactTags = document.getElementById('manageContactTags');

        if (closeContactModal) closeContactModal.addEventListener('click', () => this.closeContactModal());
        if (openChat) openChat.addEventListener('click', () => this.openContactChat());
        if (editContact) editContact.addEventListener('click', () => this.editContactInCRM());
        if (manageContactTags) manageContactTags.addEventListener('click', () => this.manageContactTags());
    }

    bindDragDropEvents() {
        // Se implementará cuando se agreguen las tarjetas dinámicamente
        document.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('contact-card')) {
                this.draggedContact = e.target.dataset.contactId;
                e.target.classList.add('dragging');
            }
        });

        document.addEventListener('dragend', (e) => {
            if (e.target.classList.contains('contact-card')) {
                e.target.classList.remove('dragging');
                this.draggedContact = null;
            }
        });

        document.addEventListener('dragover', (e) => {
            e.preventDefault();
            const columnContent = e.target.closest('.column-content');
            if (columnContent) {
                columnContent.classList.add('drag-over');
            }
        });

        document.addEventListener('dragleave', (e) => {
            const columnContent = e.target.closest('.column-content');
            if (columnContent && !columnContent.contains(e.relatedTarget)) {
                columnContent.classList.remove('drag-over');
            }
        });

        document.addEventListener('drop', (e) => {
            e.preventDefault();
            const columnContent = e.target.closest('.column-content');
            if (columnContent && this.draggedContact) {
                columnContent.classList.remove('drag-over');
                const targetColumnId = columnContent.dataset.column;
                this.moveContactToColumn(this.draggedContact, targetColumnId);
            }
        });
    }

    bindQuickActions() {
        const autoSort = document.getElementById('autoSort');
        const bulkTag = document.getElementById('bulkTag');
        const exportData = document.getElementById('exportData');

        if (autoSort) autoSort.addEventListener('click', () => this.autoSortContacts());
        if (bulkTag) bulkTag.addEventListener('click', () => this.showBulkTagModal());
        if (exportData) exportData.addEventListener('click', () => this.exportKanbanData());
    }

    // ===========================
    // FUNCIONALIDADES PRINCIPALES
    // ===========================

    async refreshKanban() {
        console.log('🔄 Actualizando Kanban...');
        await this.loadCRMData();
        this.renderKanban();
        this.updateStats();
        this.showNotification('Kanban actualizado', 'success');
    }

    showColumnModal(columnId = null) {
        const modal = document.getElementById('columnModal');
        const title = document.getElementById('columnModalTitle');
        const nameInput = document.getElementById('columnName');
        const colorInput = document.getElementById('columnColor');
        const tagSelect = document.getElementById('columnTag');
        const limitInput = document.getElementById('columnLimit');

        this.populateTagSelects();

        if (columnId) {
            const column = this.columns.find(col => col.id === columnId);
            if (column) {
                this.currentEditingColumn = columnId;
                title.textContent = 'Editar Columna';
                nameInput.value = column.name;
                colorInput.value = column.color;
                tagSelect.value = column.tagId || '';
                limitInput.value = column.limit || 0;
            }
        } else {
            this.currentEditingColumn = null;
            title.textContent = 'Nueva Columna';
            nameInput.value = '';
            colorInput.value = '#3498db';
            tagSelect.value = '';
            limitInput.value = 0;
        }

        modal.classList.add('active');
    }

    closeColumnModal() {
        const modal = document.getElementById('columnModal');
        modal.classList.remove('active');
        this.currentEditingColumn = null;
    }

    saveColumnModal() {
        const nameInput = document.getElementById('columnName');
        const colorInput = document.getElementById('columnColor');
        const tagSelect = document.getElementById('columnTag');
        const limitInput = document.getElementById('columnLimit');

        const columnData = {
            name: nameInput.value.trim(),
            color: colorInput.value,
            tagId: tagSelect.value || null,
            limit: parseInt(limitInput.value) || 0
        };

        if (!columnData.name) {
            this.showNotification('El nombre de la columna es requerido', 'error');
            return;
        }

        if (this.currentEditingColumn) {
            // Editar columna existente
            const columnIndex = this.columns.findIndex(col => col.id === this.currentEditingColumn);
            if (columnIndex !== -1) {
                this.columns[columnIndex] = { ...this.columns[columnIndex], ...columnData };
            }
        } else {
            // Crear nueva columna
            columnData.id = 'col_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            this.columns.push(columnData);
        }

        this.saveColumns();
        this.renderBoard();
        this.closeColumnModal();
        this.showNotification('Columna guardada exitosamente', 'success');
    }

    deleteColumn(columnId) {
        if (!confirm('¿Estás seguro de que deseas eliminar esta columna?')) {
            return;
        }

        const columnIndex = this.columns.findIndex(col => col.id === columnId);
        if (columnIndex !== -1) {
            const columnName = this.columns[columnIndex].name;
            this.columns.splice(columnIndex, 1);
            this.saveColumns();
            this.renderBoard();
            this.showNotification(`Columna "${columnName}" eliminada`, 'success');
        }
    }

    editColumn(columnId) {
        this.showColumnModal(columnId);
    }

    showContactModal(contactId) {
        const contact = this.contacts.find(c => c.id === contactId || c.phone === contactId);
        if (!contact) return;

        this.currentContactModal = contact;

        // Actualizar información del contacto
        document.getElementById('contactName').textContent = contact.name || contact.phone;
        document.getElementById('contactPhone').textContent = contact.phone || 'Sin teléfono';
        document.getElementById('contactLastSeen').textContent = `Última conexión: ${this.formatLastSeen(contact.lastSeen)}`;
        document.getElementById('contactAvatar').textContent = this.getContactAvatar(contact);

        // Actualizar etiquetas
        const tagsContainer = document.getElementById('contactTags');
        if (contact.tags && contact.tags.length > 0) {
            tagsContainer.innerHTML = contact.tags.map(tagId => {
                const tag = this.tags.find(t => t.id === tagId);
                return tag ? `<span class="contact-tag" style="background: ${tag.color};">${tag.name}</span>` : '';
            }).filter(tag => tag).join('');
        } else {
            tagsContainer.innerHTML = '<span class="contact-tag">Sin etiquetas</span>';
        }

        const modal = document.getElementById('contactModal');
        modal.classList.add('active');
    }

    closeContactModal() {
        const modal = document.getElementById('contactModal');
        modal.classList.remove('active');
        this.currentContactModal = null;
    }

    moveContactToColumn(contactId, targetColumnId) {
        const contact = this.contacts.find(c => c.id === contactId || c.phone === contactId);
        const targetColumn = this.columns.find(col => col.id === targetColumnId);
        
        if (!contact || !targetColumn) return;

        // Si la columna tiene una etiqueta específica, agregar esa etiqueta al contacto
        if (targetColumn.tagId) {
            if (!contact.tags) contact.tags = [];
            if (!contact.tags.includes(targetColumn.tagId)) {
                contact.tags.push(targetColumn.tagId);
            }
        }

        // Guardar cambios
        this.saveContactsToLocal();
        
        // Re-renderizar kanban
        this.renderBoard();
        this.updateStats();
        
        this.showNotification(`Contacto movido a ${targetColumn.name}`, 'success');
    }

    // ===========================
    // ACCIONES RÁPIDAS
    // ===========================

    autoSortContacts() {
        // Implementar lógica de auto-organización
        this.showNotification('Función de auto-organización en desarrollo', 'info');
    }

    showBulkTagModal() {
        // Implementar modal para etiquetado masivo
        this.showNotification('Función de etiquetado masivo en desarrollo', 'info');
    }

    exportKanbanData() {
        const data = {
            columns: this.columns,
            contacts: this.contacts,
            tags: this.tags,
            exportDate: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `kanban-crm-export-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showNotification('Datos exportados exitosamente', 'success');
    }

    openContactChat() {
        if (this.currentContactModal && this.currentContactModal.phone) {
            const whatsappUrl = `https://wa.me/${this.currentContactModal.phone.replace(/\D/g, '')}`;
            window.open(whatsappUrl, '_blank');
            this.closeContactModal();
        }
    }

    editContactInCRM() {
        // Integrar con el CRM principal para editar contacto
        if (window.whatsappCRM && this.currentContactModal) {
            window.whatsappCRM.showContactModal(this.currentContactModal.id);
            this.closeContactModal();
        } else {
            this.showNotification('CRM principal no disponible', 'error');
        }
    }

    manageContactTags() {
        // Implementar gestión de etiquetas del contacto
        this.showNotification('Gestión de etiquetas en desarrollo', 'info');
    }

    showSettings() {
        this.showNotification('Configuración en desarrollo', 'info');
    }

    // ===========================
    // UTILIDADES
    // ===========================

    updateStats() {
        this.renderSidebar();
    }

    saveColumns() {
        try {
            localStorage.setItem('wa_kanban_columns', JSON.stringify(this.columns));
        } catch (error) {
            console.error('Error guardando columnas:', error);
        }
    }

    saveContactsToLocal() {
        try {
            localStorage.setItem('wa_crm_contacts', JSON.stringify(this.contacts));
            
            // También actualizar en el CRM principal si está disponible
            if (window.whatsappCRM) {
                window.whatsappCRM.contacts = this.contacts;
                window.whatsappCRM.saveData('contacts', this.contacts);
            }
        } catch (error) {
            console.error('Error guardando contactos:', error);
        }
    }

    showNotification(message, type = 'info') {
        // Crear notificación temporal
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'error' ? '#ff6b6b' : type === 'success' ? '#51cf66' : '#339af0'};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// ===========================
// INICIALIZACIÓN
// ===========================

let kanban;

document.addEventListener('DOMContentLoaded', () => {
    kanban = new KanbanCRM();
});

// Exponer funciones globales para usar en HTML
window.kanban = {
    editColumn: (id) => kanban?.editColumn(id),
    deleteColumn: (id) => kanban?.deleteColumn(id),
    showContactModal: (id) => kanban?.showContactModal(id)
}; 